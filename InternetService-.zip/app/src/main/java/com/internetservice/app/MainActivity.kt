package com.internetservice.app

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Two WebViews (both Chromium, via Android System WebView):
 *  - ui   : the retro "Internet service" interface (assets/index.html)
 *  - site : the real browser view, placed exactly over the page area of the UI
 */
class MainActivity : ComponentActivity() {

    private lateinit var root: FrameLayout
    private lateinit var ui: WebView
    private lateinit var site: WebView

    @Volatile private var siteCanBack = false
    private var uiReady = false
    private var pendingUrl: String? = null

    private val appHost = "appassets.androidplatform.net"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        setContentView(root)
        WindowCompat.getInsetsController(window, root).isAppearanceLightStatusBars = false
        WindowCompat.getInsetsController(window, root).isAppearanceLightNavigationBars = false

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, max(bars.bottom, ime.bottom))
            insets
        }

        // ---------- UI WebView ----------
        val loader = WebViewAssetLoader.Builder()
            .setDomain(appHost)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        ui = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView, request: WebResourceRequest
                ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)

                override fun onPageFinished(view: WebView, url: String?) {
                    if (!uiReady && url?.startsWith("https://$appHost") == true) {
                        uiReady = true
                        pendingUrl?.let { openInUi(it); pendingUrl = null }
                    }
                }

                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    if (request.url.host == appHost) return false
                    val u = request.url.toString()
                    // Web links open inside this browser; only tel:/mailto: etc. go to other apps
                    if (request.url.scheme == "http" || request.url.scheme == "https") openInUi(u)
                    else openExternal(u)
                    return true
                }
            }
            addJavascriptInterface(Bridge(), "AndroidBrowser")
        }
        root.addView(ui, FrameLayout.LayoutParams(-1, -1))

        // ---------- Site WebView (the real browser) ----------
        site = WebView(this).apply {
            visibility = View.GONE
            setBackgroundColor(Color.WHITE)
            with(settings) {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                loadWithOverviewMode = true
                useWideViewPort = true
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                mediaPlaybackRequiresUserGesture = false
                setSupportMultipleWindows(false)
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    return when (request.url.scheme) {
                        "http", "https", "about", "data", "blob", "javascript" -> false
                        else -> { openExternal(request.url.toString()); true }  // tel:, mailto:, intent: ...
                    }
                }

                override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                    siteCanBack = url != "about:blank" && view.canGoBack()
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    ui.evaluateJavascript(
                        "window.onSiteProgress&&onSiteProgress($newProgress)", null
                    )
                }
            }
            setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                try {
                    val req = DownloadManager.Request(Uri.parse(url))
                        .setMimeType(mimeType)
                        .addRequestHeader("User-Agent", userAgent)
                        .addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
                        .setNotificationVisibility(
                            DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                        )
                        .setDestinationInExternalPublicDir(
                            Environment.DIRECTORY_DOWNLOADS,
                            URLUtil.guessFileName(url, contentDisposition, mimeType)
                        )
                    (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                    Toast.makeText(this@MainActivity, "Downloading...", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Download failed", Toast.LENGTH_SHORT).show()
                }
            }
        }
        root.addView(site, FrameLayout.LayoutParams(0, 0))

        // ---------- Back button ----------
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // The page decides: go back in the site, close the site, go up a menu...
                ui.evaluateJavascript("(stk.length>1||pageOn)?(back(),1):0") { r ->
                    if (r != "1") finish()
                }
            }
        })

        ui.loadUrl("https://$appHost/assets/index.html")
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** A link opened from another app (this app is a browser). */
    private fun handleIntent(i: Intent?) {
        if (i?.action != Intent.ACTION_VIEW) return
        val url = i.dataString ?: return
        if (uiReady) openInUi(url) else pendingUrl = url
    }

    private fun openInUi(url: String) {
        ui.evaluateJavascript("load(${JSONObject.quote(url)})", null)
    }

    /** Places the site WebView exactly over the page area (values are CSS px). */
    private fun applyRect(left: Double, top: Double, width: Double, height: Double) {
        val d = resources.displayMetrics.density
        site.layoutParams = FrameLayout.LayoutParams(
            (width * d).roundToInt(), (height * d).roundToInt()
        ).apply {
            leftMargin = (left * d).roundToInt()
            topMargin = (top * d).roundToInt()
        }
    }

    private fun openExternal(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot open link", Toast.LENGTH_SHORT).show()
        }
    }

    /** Called from index.html as window.AndroidBrowser.* (runs on a background thread). */
    inner class Bridge {

        @JavascriptInterface
        fun show(
            url: String, left: Double, top: Double, width: Double, height: Double,
            pics: Boolean, cookies: Boolean
        ) {
            runOnUiThread {
                // close the keyboard and size the site view to the page area
                ui.clearFocus()
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(ui.windowToken, 0)
                applyRect(left, top, width, height)
                site.settings.blockNetworkImage = !pics
                val cm = CookieManager.getInstance()
                cm.setAcceptCookie(cookies)
                cm.setAcceptThirdPartyCookies(site, cookies)
                site.visibility = View.VISIBLE
                site.loadUrl(url)
            }
        }

        @JavascriptInterface
        fun layout(left: Double, top: Double, width: Double, height: Double) {
            runOnUiThread { applyRect(left, top, width, height) }
        }

        @JavascriptInterface
        fun hide() {
            runOnUiThread {
                if (site.visibility == View.VISIBLE) {
                    site.stopLoading()
                    site.visibility = View.GONE
                    site.loadUrl("about:blank")
                    site.clearHistory()
                    siteCanBack = false
                }
            }
        }

        @JavascriptInterface
        fun canGoBack(): Boolean = siteCanBack

        @JavascriptInterface
        fun goBack() {
            runOnUiThread { if (site.canGoBack()) site.goBack() }
        }

        @JavascriptInterface
        fun external(url: String) {
            runOnUiThread { openExternal(url) }
        }

        @JavascriptInterface
        fun clearCookies() {
            runOnUiThread { CookieManager.getInstance().removeAllCookies(null) }
        }

        @JavascriptInterface
        fun clearAuth() {
            runOnUiThread { site.clearFormData() }
        }
    }

    /**
     * When the keyboard's language picker (long-press on space) or another IME popup
     * takes window focus, the keyboard can get closed. When our window gets focus back,
     * re-focus the text box the user was typing in and bring the keyboard up again.
     */
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && uiReady) {
            ui.postDelayed({
                ui.evaluateJavascript("window.restoreInp?restoreInp():false") { r ->
                    if (r == "true") {
                        ui.requestFocus()
                        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                        imm.showSoftInput(ui, InputMethodManager.SHOW_IMPLICIT)
                    }
                }
            }, 250)
        }
    }

    override fun onResume() { super.onResume(); site.onResume() }
    override fun onPause() { site.onPause(); super.onPause() }

    override fun onDestroy() {
        site.destroy()
        ui.destroy()
        super.onDestroy()
    }
}

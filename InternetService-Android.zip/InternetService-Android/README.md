# Internet service (Android)

Android Studio project. The app is a WebView wrapper around `app/src/main/assets/index.html`.

- App name: Internet service
- Version: 15.7 (versionCode 157)
- minSdk 30 (Android 11), targetSdk / compileSdk 36 (Android 16)

## Build the APK
1. Open this folder in Android Studio (Ladybug or newer) and let Gradle sync finish.
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. Debug APK: `app/build/outputs/apk/debug/app-debug.apk`

For a release / Play Store build use Build > Generate Signed Bundle / APK.

## Edit the app
Change `app/src/main/assets/index.html`, then rebuild.

Note: `gradlew` / `gradle-wrapper.jar` are not included. Android Studio uses
`gradle/wrapper/gradle-wrapper.properties` and downloads Gradle 8.11.1 itself.

## Build with GitHub Actions
Push this project to a GitHub repo (files at the repo root). The workflow in
`.github/workflows/build.yml` builds the APK on every push to main/master, or
run it manually from the Actions tab (Run workflow). Download the APK from the
run's Artifacts section (`Internet-service-apk`).

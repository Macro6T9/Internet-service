# Internet service

Retro-style browser app. Websites load in Chromium (Android System WebView).
It registers itself as a web browser, so it can be chosen as the default browser.

## Build the APK on GitHub (zip method)
1. Create a repository. Upload `InternetService.zip` (do NOT extract it).
2. Add file > Create new file > name it `.github/workflows/build.yml` and paste the workflow.
3. Open Actions > Build APK. When it finishes, download **Internet-service-apk** under Artifacts.

## Make it the default browser
Android Settings > Apps > Default apps > Browser app > Internet service.
